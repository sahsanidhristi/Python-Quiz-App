

from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel, EmailStr
from typing import List
from utils import send_email  # Assumes you have working send_email function in utils

router = APIRouter()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

# ✅ Sample quiz data
quiz_data = [
    {"id": 1, "question": "What is 2 + 2?", "options": ["3", "4", "5"], "correct": "4", "marks": 5},
    {"id": 2, "question": "What is the capital of France?", "options": ["London", "Paris", "Berlin"], "correct": "Paris", "marks": 10},
    {"id": 3, "question": "Who wrote Hamlet?", "options": ["Tolstoy", "Shakespeare", "Dante"], "correct": "Shakespeare", "marks": 15},
]

# ✅ Pydantic Models
class QuizQuestion(BaseModel):
    id: int
    question: str
    options: List[str]
    marks: int

class QuizAnswer(BaseModel):
    id: int
    answer: str

class QuizSubmit(BaseModel):
    email: EmailStr
    answers: List[QuizAnswer]

class QuizResult(BaseModel):
    total_score: int
    max_score: int
    message: str

# ✅ Endpoint to get questions
@router.get("/questions", response_model=List[QuizQuestion])
async def get_questions(token: str = Depends(oauth2_scheme)):
    return quiz_data

# ✅ Endpoint to submit quiz
@router.post("/submit", response_model=QuizResult)
async def submit_quiz(data: QuizSubmit, token: str = Depends(oauth2_scheme)):
    total_score = 0
    max_score = sum(q["marks"] for q in quiz_data)

    for answer in data.answers:
        question = next((q for q in quiz_data if q["id"] == answer.id), None)
        if question and answer.answer.strip().lower() == question["correct"].lower():
            total_score += question["marks"]

    email_body = f"Your quiz results:\n\nScore: {total_score} / {max_score}\n\nThank you for participating!"

    try:
        send_email("AI Quizzer Results", email_body, data.email)  # From utils.py
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to send email: {e}")

    return QuizResult(
        total_score=total_score,
        max_score=max_score,
        message="Quiz submitted successfully! Results emailed."
    )
