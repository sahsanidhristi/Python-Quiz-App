CREATE TABLE quizzes (
  id INTEGER PRIMARY KEY,
  grade TEXT,
  subject TEXT,
  questions TEXT,
  created_at DATETIME
);

CREATE TABLE submissions (
  id INTEGER PRIMARY KEY,
  quiz_id INTEGER,
  student_id TEXT,
  answers TEXT,
  score INTEGER,
  submitted_at DATETIME,
  FOREIGN KEY (quiz_id) REFERENCES quizzes(id)
);
