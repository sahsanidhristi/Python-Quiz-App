from fastapi import FastAPI
from auth import router as auth_router
from quiz import router as quiz_router

app = FastAPI(title="AI Quizzer")

app.include_router(auth_router, prefix="/auth", tags=["Auth"])
app.include_router(quiz_router, prefix="/quiz", tags=["Quiz"])


@app.get("/")
async def root():
    return {"message": "Welcome to AI Quizzer API"}
