import smtplib

EMAIL_ADDRESS = "dsahsani@gmail.com"
EMAIL_PASSWORD = "csgcctheupfgwsgp"

try:
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
        smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        print("Logged in successfully!")
except Exception as e:
    print("Login failed:", e)
