import streamlit as st
import requests

API_URL = "http://127.0.0.1:8000"

def login():
    st.title("AI Quizzer - Login")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    if st.button("Login"):
        response = requests.post(f"{API_URL}/auth/login", data={"username": username, "password": password})
        if response.status_code == 200:
            token = response.json()['access_token']
            st.session_state.token = token
            st.success("Login successful!")
        else:
            st.error("Login failed. Check credentials.")

def quiz():
    headers = {"Authorization": f"Bearer {st.session_state.token}"}
    questions_resp = requests.get(f"{API_URL}/quiz/questions", headers=headers)
    if questions_resp.status_code != 200:
        st.error("Failed to load quiz questions.")
        return

    questions = questions_resp.json()
    st.title("Take the Quiz")

    answers = []
    for q in questions:
        st.write(f"**{q['question']}** (Marks: {q['marks']})")
        answer = st.radio("Select answer:", q['options'], key=f"q{q['id']}")
        answers.append({"id": q['id'], "answer": answer})

    email = st.text_input("Enter your email to get results")

    if st.button("Submit Quiz"):
        if not email:
            st.error("Please enter your email.")
            return

        data = {"email": email, "answers": answers}
        submit_resp = requests.post(f"{API_URL}/quiz/submit", json=data, headers=headers)
        if submit_resp.status_code == 200:
            result = submit_resp.json()
            st.success(f"Score: {result['total_score']} / {result['max_score']}")
            st.info(result['message'])
        else:
            st.error(f"Failed to submit quiz: {submit_resp.text}")

def main():
    if "token" not in st.session_state:
        login()
    else:
        quiz()

if __name__ == "__main__":
    main()
