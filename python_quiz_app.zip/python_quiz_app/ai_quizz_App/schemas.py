from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

class QuizCreate(BaseModel):
    grade: str
    subject: str

class QuizResponse(BaseModel):
    id: int
    grade: str
    subject: str
    questions: List[dict]

class SubmissionIn(BaseModel):
    quiz_id: int
    student_id: str
    answers: List[str]

class SubmissionOut(BaseModel):
    score: int
    answers: List[str]
    submitted_at: datetime

class HistoryFilter(BaseModel):
    student_id: Optional[str]
    grade: Optional[str]
    subject: Optional[str]
    from_date: Optional[str]
    to_date: Optional[str]
